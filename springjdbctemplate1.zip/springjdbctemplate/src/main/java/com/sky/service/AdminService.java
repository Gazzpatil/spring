package com.sky.service;

import com.sky.model.Admin;

public interface AdminService
{
    public int insertAdmin(Admin admin);
    public int updateAdmin(String userName);
    public int logout(String userName);
}
