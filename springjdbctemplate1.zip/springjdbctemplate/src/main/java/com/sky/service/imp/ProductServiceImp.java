package com.sky.service.imp;

import com.sky.dao.imp.ProductDaoImp;
import com.sky.model.Product;
import com.sky.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ProductServiceImp implements ProductService {
    @Autowired
    ProductDaoImp productDaoImp;

    public ProductDaoImp getProductDaoImp() {
        return productDaoImp;
    }

    public void setProductDaoImp(ProductDaoImp productDaoImp) {
        this.productDaoImp = productDaoImp;
    }

    @Override
    public String insertProduct(Product product) {
        if(productDaoImp.insertProductDetails(product)>0){
            return "Data inserted successfully!!";
        }
        else{
            return  "something went wrong";
        }
    }

    @Override
    public List<Product> getAllProduct() {
        System.out.println("list of product");
        return productDaoImp.getAllProducts();
    }

    @Override
    public String deleteProduct(int productId) {
       if(productDaoImp.deleteProduct(productId)>0){
           return "data deleted successfully";
       }
        else{
            return "data not deleted";
       }
    }

    @Override
    public void updateProduct(Product product) {
        productDaoImp.updateProduct(product);
    }

    @Override
    public Product getProductById(String id) {
      return   productDaoImp.getProductById(id);
    }




//    public void setDaoImp(ProductDaoImp daoImp) {
//    }
}
