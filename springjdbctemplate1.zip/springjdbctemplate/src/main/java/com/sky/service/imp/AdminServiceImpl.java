package com.sky.service.imp;

import com.sky.dao.AdminDao;
import com.sky.model.Admin;
import com.sky.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminDao adminDao;
    @Override
    public int insertAdmin(Admin admin) {
        return adminDao.insertAdmin(admin);
    }

    public int updateAdmin(String userName){
        return adminDao.updateAdmin(userName);
    }

    @Override
    public int logout(String userName) {
        return adminDao.logout(userName);
    }

}
