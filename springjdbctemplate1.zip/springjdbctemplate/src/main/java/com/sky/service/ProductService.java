package com.sky.service;

import com.sky.model.Product;

import java.util.List;

public interface ProductService {

    public String insertProduct(final Product product);

    public List<Product> getAllProduct();

    public String deleteProduct(final int productId);

    public void updateProduct(Product product);

    public Product getProductById(final String id);



}
