package com.sky.controller;

import com.sky.model.Admin;
import com.sky.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;

@Controller
public class SecurityController {
    @Autowired
    AdminService adminService;
    Admin admin;
    @Autowired
    private HttpServletRequest httpServletRequest;

    @RequestMapping("/test1")
    @ResponseBody
    public String test1() {
        return "test1 securityy....";
    }

    @RequestMapping("/test5")
    @ResponseBody
    public String test() {
        return "test5 spring security";
    }

    /* Spring Security Custom */
    @RequestMapping(value = "signin", method = RequestMethod.GET)
    public String login() {
        return "login";
    }


    @RequestMapping(value = "/loginError", method = RequestMethod.GET)
    public String loginError(Model model) {
        model.addAttribute("admin", new Admin());
        model.addAttribute("error", "true");
        model.addAttribute("msg", "invalid credentials try again");
        return "login";
    }
    @RequestMapping("/logOut")
    public String logout(HttpServletRequest servletRequest,Model model){

        model.addAttribute("logOutMsg","logged out successfully");
        Cookie[] cookies = httpServletRequest.getCookies();
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("userName")){
                String value = cookie.getValue();
                System.out.println(value);
                adminService.logout(value);
            }
        }



        return "login";
    }

    @RequestMapping("/form")
    public String form(Model model) {
        model.addAttribute("form", new Admin());
        return "formAdmin";
    }




    @RequestMapping(value = "/saveAdmin", method = RequestMethod.POST)
    public String insertAdmin(@ModelAttribute("admin") Admin admin, Model model) {

        adminService.insertAdmin(admin);
        return "insertAdmin";
    }

    @RequestMapping("/admin")
    public String admin(){
        return "admin";
    }

    @RequestMapping("/user")
    @ResponseBody
    public String user(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse){

//        cookie
        Cookie cookie = new Cookie("name", "patil");
        httpServletResponse.addCookie(cookie);


//session
        httpServletRequest.getSession().setAttribute("userName","gajanand");
    return  "loginSuccessful";
    }

    @RequestMapping("/getValueSession")
    @ResponseBody
    public String gettingValueFromServlet(HttpServletRequest servletRequest){

       return (String) servletRequest.getSession().getAttribute("userName");
    }

    @RequestMapping("/getValueCookie")
    @ResponseBody
    public String gettingValueFromCookie(HttpServletRequest httpServletRequest){
    for(Cookie cookie : httpServletRequest.getCookies()){
        if(cookie.getName().equals("name")){
            System.out.println(cookie.getValue());
            return cookie.getValue();
        }
    }
        return null;

}

}
