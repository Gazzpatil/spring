package com.sky.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sky.model.Product;
import com.sky.restweb.RestWebService;
import com.sky.service.imp.ProductServiceImp;
import com.sky.validator.ProductValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {
    @Autowired
    RestWebService restWebService;

    @Autowired
    ProductServiceImp productServiceImp;

    @Autowired
    ProductValidator productValidator;


    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping(value = "/getForm", method = RequestMethod.GET)
    public String getForm(Model model) {
        System.out.println("opened form page");
        model.addAttribute("product", new Product());
        return "form";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String save(@Valid @ModelAttribute("product") Product product, Model model, BindingResult bindingResult) {
        productValidator.validate(product, bindingResult);
        if (!bindingResult.hasErrors()) {
            productServiceImp.insertProduct(product);
            return "msg";
        } else {
            return "form";
        }

    }

    @RequestMapping("/listofProduct")
    public String getAllProduct(Model model) {
        List<Product> listProduct = productServiceImp.getAllProduct();
//        for(Product l:listProduct){
//            System.out.println(l);
//        }
        for(Product list: listProduct){
            System.out.println(list);
        }
        model.addAttribute("list", listProduct);
        return "list";
    }

    @RequestMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") int id, Model model) {
        model.addAttribute("delete", productServiceImp.deleteProduct(id));
        return "redirect:/listofProduct";
    }


    @RequestMapping("/product/{id}")
    public String getProductById(@PathVariable("id") String id, Model model) {
        System.out.println(productServiceImp.getProductById(id));
        model.addAttribute("pid", productServiceImp.getProductById(id));
        return "getById";
    }

    @RequestMapping("/update/{productId}")
    public String update(@PathVariable("productId") String productId, Model model) {
        Product product = productServiceImp.getProductDaoImp().getProductById(productId);
        model.addAttribute("data", product);
        return "update";
    }

    @RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
    public String updateProduct(@ModelAttribute("data") Product product, Model model) {
//  System.out.println("Working");
        productServiceImp.updateProduct(product);
        System.out.println(product.getProductId());
        List<Product> list = new ArrayList<>();
        list.add(product);
        model.addAttribute("list", list);
        return "redirect:/list";
    }


    /* Spring Security  Basic */



//       @RequestMapping("/resp")
//        public Stri @RequestMapping(value = "/logOut",method = RequestMethod.GET)
////        public String logout(Model model){
////            model.addAttribute("logout message","logged out successfully!!!!");
////            return  "login";
////        }ng getResponse(){
//        return "hi everyone";
//        }

//    @RequestMapping(value = "/updateEmployee", method = RequestMethod.POST)
//    public String updateEmployee(
//            @RequestParam("id") int id,
//            @RequestParam("name") String name,
//            @RequestParam("designation") String designation) {
//        Employee employee = new Employee();
//        employee.setId(id);
//        employee.setName(name);
//        employee.setDesignation(designation);
//        employeeService.updateEmployee(employee);
//        return "redirect:/employeeList"; // Redirect to a page showing updated employee list
//    }

    @RequestMapping("/customApi")
    @ResponseBody
    public Product readCustomApi() throws JsonProcessingException {
        return restWebService.readData();
    }


}
