package com.sky.dao.imp;

import com.sky.dao.ProductDao;
import com.sky.model.Product;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ProductDaoImp implements ProductDao {
    
    JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int insertProductDetails(Product product) {
        String query="insert into product(productId,productName,productBrand,productPrice)values('"+product.getProductId()+"','"+product.getProductName()+"','"+product.getProductBrand()+"','"+product.getProductPrice()+"')";
        return jdbcTemplate.update(query);
    }

    @Override
    public Product getProductById(String productId) {
        String sql="select * from product where productId=?";
        return jdbcTemplate.queryForObject(sql,new Object[] {productId},new BeanPropertyRowMapper<Product>(Product.class));
    }

    @Override
    public List<Product> getAllProducts() {

         List<Product> list = jdbcTemplate.query("select * from product", new RowMapper<Product>() {
            @Override
            public Product mapRow(final ResultSet rs,final int rowNum) throws SQLException{
              Product product=new Product();
              product.setProductId(Integer.parseInt(rs.getString("productId")));
              product.setProductName(rs.getString("productName"));
              product.setProductBrand(rs.getString("productBrand"));
              product.setProductPrice(Integer.parseInt(rs.getString("productPrice")));
              return product;
            }
        });
        return list;
    }

    @Override
    public int deleteProduct(int productId) {
        String query="delete from data.product where  productId=?";
        return jdbcTemplate.update(query,productId);
    }

    @Override
    public void updateProduct(Product product) {
        String query="update product set productName=?,productBrand=?,productPrice=? where productId=?";
        jdbcTemplate.update(query,product.getProductName(),product.getProductBrand(),product.getProductPrice(),product.getProductId());
    }



//    @Override
//    public int deleteProduct(String productId) {
//
//        return 0;
//    }

/*
 public int insertProductDetails(Product product) {
        String query="insert into product(productId,productName,productBrand,productPrice)values('"+product.getProductId()+"','"+product.getProductName()+"','"+product.getProductBrand()+"','"+product.getProductPrice()+"')";
        return jdbcTemplate.update(query);
    }

    public void updateEmployee(Employee employee)
 */


    /*public int update(Emp p){
    String sql="update Emp99 set name='"+p.getName()+"', salary="+p.getSalary()+",designation='"+p.getDesignation()+"' where id="+p.getId()+"";
    return template.update(sql);
}*/


}
