package com.sky.dao.imp;

import com.sky.dao.AdminDao;
import com.sky.model.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public class AdminDaoImp implements AdminDao {
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Override
    public int insertAdmin(Admin admin) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String hashedPassword = passwordEncoder.encode(admin.getPassword());

        System.out.println("encripted password -------|| "+hashedPassword);

        String query="insert into admin values(?,?,?,?,?)";
        return jdbcTemplate.update(query,admin.getUserName(),hashedPassword,admin.getRole(),admin.getLogin(),admin.getLogout());
    }


    public int updateAdmin(String userName) {
        String query="update admin set login=? where userName=?";
       String time=LocalDateTime.now().toString();
        return jdbcTemplate.update(query,time,userName);
    }

    @Override
    public int logout(String userName) {
        String query="update admin set logout=? where userName=?";
        String time=LocalDateTime.now().toString();
        return jdbcTemplate.update(query,time,userName);
    }


}
