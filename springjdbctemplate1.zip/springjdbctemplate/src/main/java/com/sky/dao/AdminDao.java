package com.sky.dao;

import com.sky.model.Admin;
import org.springframework.stereotype.Repository;


public interface AdminDao {
    public int insertAdmin(Admin admin);
    public int updateAdmin(String userName);
    public int logout(String userName);
}
