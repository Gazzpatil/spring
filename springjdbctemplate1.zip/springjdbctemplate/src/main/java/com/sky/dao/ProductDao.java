package com.sky.dao;

import com.sky.model.Product;

import java.util.List;

public interface ProductDao {

    public int insertProductDetails(final Product product);

    public Product getProductById(final String id);


    public List<Product> getAllProducts();

    public int deleteProduct(final int productId);

    public void updateProduct(Product product);



    /*
     public void updateEmployee(Employee employee) {
        String query = "UPDATE employees SET name=?, designation=? WHERE id=?";
        jdbcTemplate.update(query, employee.getName(), employee.getDesignation(), employee.getId());
    }
     */

}
