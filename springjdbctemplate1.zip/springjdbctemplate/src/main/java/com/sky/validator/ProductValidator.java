package com.sky.validator;


import com.sky.model.Product;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Product.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Product product = (Product) target;

        if(product.getProductId()<10)
        {
            errors.rejectValue("productId","productId.error","Please use greather than 10");
        }

        if(product.getProductBrand().equals("SAM")){
            errors.rejectValue("productBrand","productBrand.error","Brand Name should not be SAM");
        }
       /* // Regular expression pattern for name validation
        String nameRegex = "^[a-zA-Z]+$";
        String name = product.getProductName(); // Assuming there is a getName() method in the Product class

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(nameRegex);

        // Create a matcher with the input string
        Matcher matcher = pattern.matcher(name);

        // Check if the name matches the pattern
        if (!matcher.matches()) {
            errors.rejectValue("productName", "name.error", "Name should contain only letters");
        }*/
        if(!validName(product.getProductName())){
            errors.rejectValue("productName","productName.error","name should be only letters");
        }
    }

    public boolean validName(String productName){
        Pattern p=Pattern.compile("[a-zA-Z\\s]+");
        Matcher m=p.matcher(productName);
        return m.matches();
    }

}
