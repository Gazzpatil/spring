package com.sky.handler;

import com.sky.service.imp.AdminServiceImpl;
import com.sky.service.imp.ProductServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.Collection;

import static java.lang.System.out;

public class CustomHandlerSuccess implements AuthenticationSuccessHandler {
    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
    ProductServiceImp productServiceImp;
    @Autowired
   AdminServiceImpl adminService;
    private User user;
    private HttpServletRequest httpServletRequest;

    public RedirectStrategy getRedirectStrategy() {
        return redirectStrategy;
    }

    public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
        this.redirectStrategy = redirectStrategy;
    }

    public AdminServiceImpl getAdminService() {
        return adminService;
    }

    public void setAdminService(AdminServiceImpl adminService) {
        this.adminService = adminService;
    }

    public ProductServiceImp getProductServiceImp() {
        return productServiceImp;
    }

    public void setProductServiceImp(ProductServiceImp productServiceImp) {
        this.productServiceImp = productServiceImp;
    }


    @Override
    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
        out.println("inside authentication success handler");

        if(authentication.isAuthenticated())
        {
            out.println("authentication is authenticated");
            User principal = (User) authentication.getPrincipal();




            String userName = principal.getUsername();
            out.println("username is " + userName);
            adminService.updateAdmin(userName);

            /*
            adding cookie in response
                            */

            Cookie cookie=new Cookie("userName",principal.getUsername());
            httpServletResponse.addCookie(cookie);




            /*                 Creating  Session                */

            HttpSession session = httpServletRequest.getSession();
            session.setAttribute("userName", "gajanand");




            Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
            for (GrantedAuthority grantedAuthority : authorities) {

                if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
                    redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/admin");
                } else if (grantedAuthority.getAuthority().equals("ROLE_USER")) {
                    redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/user");
                } else {
                    redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/listofProduct");
                }
            }
        }
    }
}




