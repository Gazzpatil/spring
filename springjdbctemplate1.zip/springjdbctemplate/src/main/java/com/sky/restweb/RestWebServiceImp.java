package com.sky.restweb;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysql.cj.protocol.x.XProtocolRow;
import com.sky.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class RestWebServiceImp implements  RestWebService{
    @Autowired
    RestTemplate restTemplate;

    @Override
    public Product getProductData() {
        Product product=new Product();
        product.setProductId(20);
        product.setProductName("earbuds");
        product.setProductBrand("boat");
        product.setProductPrice(999);
        return product;
    }

    @Override
    public Product getProductById(String productId) {
        return null;
    }




//    @Override
//    public String readData() throws JsonProcessingException {
//        Product product=getProductData();
//        ObjectMapper objectMapper=new ObjectMapper();
//        String s = objectMapper.writeValueAsString(product);
//        return s;
//    }

    @Override
    public Product readData() {
        Product product=getProductData();
       return product ;
    }

    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }
}
