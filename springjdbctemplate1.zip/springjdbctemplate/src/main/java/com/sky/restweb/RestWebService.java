package com.sky.restweb;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sky.model.Product;

public interface RestWebService {
    Product getProductData();

    public Product getProductById(String productId);

    Product readData();



}
